#!/usr/bin/env python3
# authz.py
# Role-based authorization for the broker's admin endpoints.
#
# The problem this solves: every admin endpoint currently uses
# require_keycloak_auth, which only checks that the token is VALID — any
# authenticated user can create groups, assign roles, or delete organizations.
# For multi-tenant SaaS that's unacceptable: a customer's ordinary user could
# delete their organization or read across tenants.
#
# This adds AUTHORIZATION on top of authentication: require_role("x") produces a
# FastAPI dependency that (1) validates the token as before, then (2) checks the
# token carries role "x", raising 403 if not. 401 = "who are you?" (bad token);
# 403 = "I know who you are, you're not allowed" (valid token, missing role).
#
# Roles come from Keycloak's token introspection response, which nests them:
#   realm_access.roles:            realm-wide roles (e.g. "tenant-admin")
#   resource_access.<client>.roles: client-scoped roles
# We check both, so a role granted either way satisfies the requirement.

from __future__ import annotations

from typing import Callable, Iterable

from fastapi import Depends, HTTPException


def extract_roles(token_info: dict) -> set[str]:
    """Collect all roles from a Keycloak introspection response.

    Merges realm roles and every client's resource roles into one set. Missing
    or malformed sections are treated as "no roles there" rather than errors —
    a token without the section simply has none of those roles.
    """
    roles: set[str] = set()

    realm = token_info.get("realm_access")
    if isinstance(realm, dict):
        r = realm.get("roles")
        if isinstance(r, list):
            roles.update(str(x) for x in r)

    resource = token_info.get("resource_access")
    if isinstance(resource, dict):
        for client_block in resource.values():
            if isinstance(client_block, dict):
                r = client_block.get("roles")
                if isinstance(r, list):
                    roles.update(str(x) for x in r)

    return roles


def user_has_any_role(token_info: dict, required: Iterable[str]) -> bool:
    """True if the token carries at least one of the required roles."""
    have = extract_roles(token_info)
    return any(r in have for r in required)


# Claims that may carry the user's organization/tenant membership. Keycloak and
# Auth0 both can emit an "organization" claim; we also accept a few common
# alternatives so this works across IdP configurations without code changes.
_ORG_CLAIMS = ("organizations", "organization", "org", "orgs", "tenant", "tenants")


def extract_org_ids(token_info: dict) -> set[str]:
    """Collect the organization/tenant ids the token's subject belongs to.

    Looks across the common claim names and normalizes the several shapes an org
    claim takes in the wild:
      - a list of ids:            ["org_a", "org_b"]
      - a single id string:       "org_a"
      - Auth0-style dict keyed by id: {"org_a": {...}, "org_b": {...}}
      - a list of dicts with id/name: [{"id": "org_a"}, ...]
    Unknown/missing claims yield an empty set (no access), never an error.
    """
    ids: set[str] = set()
    for claim in _ORG_CLAIMS:
        val = token_info.get(claim)
        if val is None:
            continue
        if isinstance(val, str):
            ids.add(val)
        elif isinstance(val, dict):
            # Auth0 organizations claim: keys are the org ids.
            ids.update(str(k) for k in val.keys())
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, str):
                    ids.add(item)
                elif isinstance(item, dict):
                    # dict entries: prefer an explicit id, fall back to name.
                    oid = item.get("id") or item.get("org_id") or item.get("name")
                    if oid is not None:
                        ids.add(str(oid))
    return ids


def user_can_access_org(token_info: dict, *org_refs: str) -> bool:
    """True if the token's subject belongs to an org matching ANY of the given
    references. Pass an org's id and name together so the check succeeds whether
    the token claim carries ids or names (they're different identifiers for the
    same org). None/empty refs are ignored."""
    accessible = extract_org_ids(token_info)
    return any(ref in accessible for ref in org_refs if ref)


def make_require_role(introspect_dependency: Callable) -> Callable:
    """Build the require_role factory, wired to the app's auth dependency.

    Passing the introspection dependency in (rather than importing it) keeps this
    module decoupled from main.py and trivially testable: a test can supply a
    fake dependency that returns any token_info it wants.

    Usage in main.py:
        require_role = make_require_role(require_keycloak_auth)
        @app.post("/groups")
        def create_group(token_info = Depends(require_role("tenant-admin"))):
            ...
    """
    def require_role(*allowed_roles: str) -> Callable:
        if not allowed_roles:
            raise ValueError("require_role needs at least one role")

        def dependency(token_info: dict = Depends(introspect_dependency)) -> dict:
            # token_info is already validated (active, not expired) by the
            # injected dependency. Now the authorization check:
            if not user_has_any_role(token_info, allowed_roles):
                # 403, not 401: the caller IS authenticated, just not permitted.
                # We name the required role(s) so an operator debugging a denied
                # request knows what's missing — but reveal nothing about the
                # token itself.
                raise HTTPException(
                    status_code=403,
                    detail=("Forbidden: requires one of role(s): "
                            + ", ".join(sorted(allowed_roles))),
                )
            return token_info

        return dependency

    return require_role


def enforce_org_access(token_info: dict, *org_refs: str,
                       superadmin_roles: Iterable[str] = ()) -> None:
    """Raise 403 unless the token's subject may act on the referenced org.

    This is the tenant-isolation check: a tenant-admin of org A must not be able
    to modify org B. Call it from any endpoint that identifies an org, passing
    the validated token_info and one or more references to the SAME org (e.g.
    both its id and its name) — access is granted if the token matches any of
    them, so it works whether the IdP claim carries ids or names.

    A caller holding one of `superadmin_roles` bypasses the scope check — that's
    the platform operator who legitimately manages all tenants.

    Kept as a plain function (not a dependency) because the org reference usually
    comes from the path/body of the specific endpoint, which a generic dependency
    can't know — the endpoint calls this after reading its own org reference.
    """
    if superadmin_roles and user_has_any_role(token_info, superadmin_roles):
        return  # platform superadmin: cross-tenant access is intended
    if not user_can_access_org(token_info, *org_refs):
        shown = next((r for r in org_refs if r), "?")
        raise HTTPException(
            status_code=403,
            detail=("Forbidden: you do not have access to organization "
                    f"'{shown}'"),
        )


def is_superadmin(token_info: dict, superadmin_roles: Iterable[str]) -> bool:
    """True if the token holds a role that grants cross-tenant (platform) access."""
    return bool(superadmin_roles) and user_has_any_role(token_info, superadmin_roles)


def filter_orgs_to_accessible(token_info: dict, orgs: list,
                              superadmin_roles: Iterable[str] = (),
                              id_key: str = "id",
                              name_key: str = "name") -> list:
    """Filter a list of organization objects to those the caller may see.

    Tenant isolation for READ: a tenant-admin listing organizations should only
    get back their own, not every tenant's. A superadmin gets the full list.

    Each org is matched by its id OR name against the caller's org claim, so this
    works whether the token carries ids or names. Non-dict entries are dropped
    defensively.
    """
    if not orgs:  # None or empty — nothing to filter for anyone
        return orgs if orgs is not None else []
    if is_superadmin(token_info, superadmin_roles):
        return orgs
    accessible = extract_org_ids(token_info)
    out = []
    for org in orgs:
        if not isinstance(org, dict):
            continue
        oid = org.get(id_key)
        oname = org.get(name_key)
        if (oid is not None and str(oid) in accessible) or \
           (oname is not None and str(oname) in accessible):
            out.append(org)
    return out


def shares_org(token_info: dict, target_org_refs: Iterable[str],
               superadmin_roles: Iterable[str] = ()) -> bool:
    """True if the caller shares at least one organization with a target.

    Used to tenant-scope user lookups: the caller may only inspect a user who
    belongs to one of the caller's own organizations. A superadmin always
    matches. target_org_refs is the set of org ids/names the TARGET belongs to.
    """
    if is_superadmin(token_info, superadmin_roles):
        return True
    caller_orgs = extract_org_ids(token_info)
    return any(str(ref) in caller_orgs for ref in target_org_refs if ref)


def enforce_shared_org(token_info: dict, target_org_refs: Iterable[str],
                       superadmin_roles: Iterable[str] = ()) -> None:
    """Raise 403 unless the caller shares an org with the target user.

    Tenant isolation for user lookups. If the target belongs to no orgs the
    caller can see, the lookup is denied — a tenant-admin can't inspect users
    outside their tenant(s).
    """
    if not shares_org(token_info, target_org_refs, superadmin_roles):
        raise HTTPException(
            status_code=403,
            detail="Forbidden: target user is not in your organization(s)")


def extract_scopes(token_info: dict) -> set[str]:
    """Collect the OAuth scopes from an introspection response.

    Keycloak returns granted scopes in the space-delimited 'scope' claim.
    Missing/malformed -> empty set (the token has no scopes), never an error.
    """
    raw = token_info.get("scope")
    if not isinstance(raw, str):
        return set()
    return {s for s in raw.split() if s}


def extract_audiences(token_info: dict) -> set[str]:
    """Collect the audiences ('aud' claim) from an introspection response.

    'aud' may be a single string or a list of strings. Normalizes both to a set.
    """
    aud = token_info.get("aud")
    if isinstance(aud, str):
        return {aud}
    if isinstance(aud, list):
        return {str(a) for a in aud}
    return set()


def token_has_scope(token_info: dict, required: Iterable[str]) -> bool:
    """True if the token carries ALL of the required scopes."""
    have = extract_scopes(token_info)
    return all(s in have for s in required)


def enforce_scope(token_info: dict, *required_scopes: str) -> None:
    """Raise 403 unless the token carries every one of the required scopes.

    Lets an endpoint demand that a token was minted for a specific purpose —
    e.g. an app whose token has scope 'orders:read' can read orders but a token
    without it is refused, even if it's otherwise valid and authenticated. This
    is the token-constraint counterpart to require_role (which checks identity's
    roles); scopes constrain what a given TOKEN may do, independent of the
    holder's full permissions.
    """
    scopes = [s for s in required_scopes if s]
    if not scopes:
        return
    if not token_has_scope(token_info, scopes):
        have = extract_scopes(token_info)
        missing = [s for s in scopes if s not in have]
        raise HTTPException(
            status_code=403,
            detail=f"Token is missing required scope(s): {', '.join(missing)}")

def token_has_audience(token_info: dict, required: Iterable[str]) -> bool:
    """True if the token carries at least one of the required audiences."""
    have = extract_audiences(token_info)
    return any(a in have for a in required)


def enforce_audience(token_info: dict, *required_audiences: str) -> None:
    """Raise 403 unless the token carries at least one of the required audiences.

    Audience restriction: a token's 'aud' claim names the services it was minted
    for. An endpoint fronting service X calls enforce_audience(token_info, "X")
    so a token intended only for service Y is refused — even when it's otherwise
    valid, authenticated, and correctly scoped. This is the "where may this token
    be USED" counterpart to enforce_scope's "what may this token DO": a token can
    carry the right scope yet be meant for a different audience, and vice versa.

    "At least one" match, matching normal aud semantics (a token may legitimately
    list several audiences; the service passes if it's one of them). No required
    audiences -> no-op, so an unconstrained endpoint stays open.
    """
    auds = [a for a in required_audiences if a]
    if not auds:
        return
    if not token_has_audience(token_info, auds):
        raise HTTPException(
            status_code=403,
            detail="Token audience not accepted here; requires one of: "
                   + ", ".join(auds))
