#!/usr/bin/env python3
# integration_test_live.py
# LIVE integration test: runs the app's real Keycloak setup against a REAL
# Keycloak, then exercises the real auth loop over HTTP. This is the test that
# catches the class of bug the mocked suite cannot — the realm-never-created and
# user-not-fully-set-up bugs both passed hundreds of mocked tests and only broke
# against a real Keycloak.
#
# It is deliberately NOT a pytest test: it needs a real Keycloak reachable at
# KEYCLOAK_URL, so it runs as its own CI job (see .github/workflows/ci.yml,
# job 'live-integration') rather than in the unit-test run.
#
# Exit code 0 = all checks passed; non-zero = a real failure.
#
# Required env (CI sets these; locally, point at your own Keycloak):
#   KEYCLOAK_URL            e.g. http://localhost:8080
#   KEYCLOAK_REALM          e.g. Premkey
#   KEYCLOAK_ADMIN_USER     e.g. admin
#   KEYCLOAK_ADMIN_PASSWORD e.g. admin
#   DEFAULT_USER_PASSWORD   the password the app sets on the default 'user'

from __future__ import annotations

import os
import sys
import threading
import time

import requests


PORT = int(os.environ.get("INTEGRATION_APP_PORT", "8099"))
BASE = f"http://127.0.0.1:{PORT}"
DEFAULT_USER = os.environ.get("INTEGRATION_KC_USER", "user")
DEFAULT_PASS = os.environ.get("DEFAULT_USER_PASSWORD", "testpass123")


class Checks:
    def __init__(self):
        self.failed: list[str] = []

    def check(self, name: str, cond: bool, detail: str = ""):
        mark = "\u2713" if cond else "\u2717"
        print(f"  {mark} {name}" + (f" — {detail}" if detail else ""))
        if not cond:
            self.failed.append(name + (f": {detail}" if detail else ""))


def _wait_for_keycloak(url: str, timeout: int = 180) -> bool:
    """Poll the master realm until Keycloak answers or we give up."""
    deadline = time.time() + timeout
    probe = url.rstrip("/") + "/realms/master"
    while time.time() < deadline:
        try:
            if requests.get(probe, timeout=5).status_code == 200:
                return True
        except requests.RequestException:
            pass
        time.sleep(3)
    return False


def _start_app() -> threading.Thread:
    """Launch the FastAPI app (real lifespan → real Keycloak setup) in-process."""
    import uvicorn
    import main

    def serve():
        uvicorn.run(main.app, host="127.0.0.1", port=PORT, log_level="warning")

    t = threading.Thread(target=serve, daemon=True)
    t.start()
    return t


def _wait_for_app(timeout: int = 90) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if requests.get(BASE + "/", timeout=3).status_code == 200:
                return True
        except requests.RequestException:
            pass
        time.sleep(2)
    return False


def main_run() -> int:
    print("=" * 68)
    print("LIVE KEYCLOAK INTEGRATION TEST")
    print("=" * 68)
    kc_url = os.environ.get("KEYCLOAK_URL", "http://localhost:8080")
    print(f"Keycloak: {kc_url}")
    print(f"App:      {BASE}")

    c = Checks()

    # 1. Keycloak must be reachable before we start the app.
    print("\n[1] Keycloak reachability")
    if not _wait_for_keycloak(kc_url):
        print(f"  \u2717 Keycloak never became ready at {kc_url}")
        return 1
    print("  \u2713 Keycloak is up")

    # 2. Start the app — this runs the REAL setup_keycloak (_ensure_realm,
    #    client creation, default-user finalization) against real Keycloak.
    print("\n[2] App startup (runs real Keycloak provisioning)")
    _start_app()
    if not _wait_for_app():
        print("  \u2717 App did not become ready — startup/provisioning failed")
        print("      (this is exactly the failure the realm/user bugs caused)")
        return 1
    print("  \u2713 App started — realm, client, and default user provisioned")

    # 3. The real auth loop over HTTP.
    print("\n[3] Auth loop")
    # 3a. token with valid credentials
    try:
        r = requests.post(BASE + "/token",
                          data={"username": DEFAULT_USER, "password": DEFAULT_PASS},
                          timeout=15)
        c.check("POST /token (valid creds) -> 200", r.status_code == 200,
                f"got {r.status_code}: {r.text[:120]}" if r.status_code != 200 else "")
        token = r.json().get("access_token") if r.status_code == 200 else None
    except requests.RequestException as exc:
        c.check("POST /token", False, str(exc))
        token = None

    # 3b. token with bad credentials must be rejected
    try:
        rb = requests.post(BASE + "/token",
                          data={"username": DEFAULT_USER, "password": "wrong-pw"},
                          timeout=15)
        c.check("POST /token (bad creds) -> 401", rb.status_code == 401,
                f"got {rb.status_code}")
    except requests.RequestException as exc:
        c.check("POST /token (bad creds)", False, str(exc))

    # 3c. protected with token
    if token:
        try:
            p = requests.get(BASE + "/protected",
                            headers={"Authorization": f"Bearer {token}"}, timeout=15)
            c.check("GET /protected (with token) -> 200", p.status_code == 200,
                    f"got {p.status_code}")
        except requests.RequestException as exc:
            c.check("GET /protected (with token)", False, str(exc))

        # 3d. introspection
        try:
            o = requests.post(BASE + "/oidc-token",
                             headers={"Authorization": f"Bearer {token}"}, timeout=15)
            c.check("POST /oidc-token (introspect) -> 200", o.status_code == 200,
                    f"got {o.status_code}")
        except requests.RequestException as exc:
            c.check("POST /oidc-token", False, str(exc))

    # 3e. protected without token must be rejected (security assertion)
    try:
        a = requests.get(BASE + "/protected", timeout=15)
        c.check("GET /protected (anonymous) -> 401", a.status_code == 401,
                f"got {a.status_code}")
    except requests.RequestException as exc:
        c.check("GET /protected (anonymous)", False, str(exc))

    # 4. Idempotency: running setup again against the now-provisioned Keycloak
    #    must not crash (restarts hit this constantly).
    print("\n[4] Setup idempotency")
    try:
        import main
        main._setup_keycloak_with_retry()
        c.check("second setup run is idempotent", True)
    except Exception as exc:  # noqa: BLE001
        c.check("second setup run is idempotent", False, str(exc))

    # 5. Groups pagination: list_groups must return ALL groups, walking pages.
    #    Verified live against real Keycloak — creates >100 groups (crossing the
    #    page boundary that a single-request implementation could truncate) and
    #    confirms every one comes back. This exercises the auth0_talk.list_groups
    #    pagination fix against a real server, not a mock of the response shape.
    print("\n[5] Groups pagination (list_groups walks all pages)")
    try:
        import requests as _rq
        from auth0_talk import KeycloakAdminAPI
        realm = os.environ.get("KEYCLOAK_REALM", "Premkey")
        admin_user = os.environ.get("KEYCLOAK_ADMIN_USER", "admin")
        admin_pass = os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")
        tok = _rq.post(
            kc_url.rstrip("/") + "/realms/master/protocol/openid-connect/token",
            data={"grant_type": "password", "client_id": "admin-cli",
                  "username": admin_user, "password": admin_pass},
            timeout=15).json().get("access_token")
        if not tok:
            c.check("obtained admin token for groups test", False, "no token")
        else:
            hdr = {"Authorization": f"Bearer {tok}",
                   "Content-Type": "application/json"}
            base = kc_url.rstrip("/") + f"/admin/realms/{realm}/groups"
            # Create 120 groups (crosses the 100/page boundary). Idempotent-ish:
            # a 409 on re-run is fine.
            made = 0
            for i in range(120):
                r = _rq.post(base, headers=hdr,
                             json={"name": f"pgtest-{i:04d}"}, timeout=10)
                if r.status_code in (201, 409):
                    made += 1
            api = KeycloakAdminAPI(kc_url.rstrip("/"), tok, realm)
            all_groups = api.list_groups()
            pgtest = [g for g in all_groups if g.get("name", "").startswith("pgtest-")]
            c.check("list_groups returns all >100 groups (paginated)",
                    len(pgtest) >= 120,
                    f"expected >=120 pgtest groups, got {len(pgtest)}")
    except Exception as exc:  # noqa: BLE001
        c.check("groups pagination", False, str(exc))

    # 6. Role provisioning: setup_keycloak must create the admin role and grant
    #    it to the admin user, so the authorization layer is usable. Verified
    #    live because the python-keycloak role method names can't be confirmed by
    #    mocks.
    print("\n[6] Admin role provisioning")
    try:
        import requests as _rq2
        realm = os.environ.get("KEYCLOAK_REALM", "Premkey")
        admin_role = os.environ.get("ADMIN_ROLE", "tenant-admin")
        admin_username = os.environ.get("ADMIN_USERNAME", "admin-user")
        admin_user = os.environ.get("KEYCLOAK_ADMIN_USER", "admin")
        admin_pass = os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")
        tok = _rq2.post(
            kc_url.rstrip("/") + "/realms/master/protocol/openid-connect/token",
            data={"grant_type": "password", "client_id": "admin-cli",
                  "username": admin_user, "password": admin_pass},
            timeout=15).json().get("access_token")
        hdr = {"Authorization": f"Bearer {tok}"}
        base = kc_url.rstrip("/") + f"/admin/realms/{realm}"
        roles = _rq2.get(base + "/roles", headers=hdr, timeout=10).json()
        c.check(f"realm role '{admin_role}' provisioned",
                any(r.get("name") == admin_role for r in roles),
                "role not found in realm")
        users = _rq2.get(base + f"/users?username={admin_username}",
                         headers=hdr, timeout=10).json()
        if users:
            uid = users[0]["id"]
            urs = _rq2.get(base + f"/users/{uid}/role-mappings/realm",
                           headers=hdr, timeout=10).json()
            c.check(f"admin user has '{admin_role}' role",
                    any(r.get("name") == admin_role for r in urs),
                    "admin user missing the role")
        else:
            c.check("admin user provisioned", False, "admin user not found")
    except Exception as exc:  # noqa: BLE001
        c.check("role provisioning", False, str(exc))

    # 7. Tenant scoping: verify the authz layer correctly reads roles and org
    #    membership from a REAL Keycloak-issued token (introspected), and that
    #    enforcement denies cross-tenant access. Roles come from real Keycloak;
    #    the org claim is injected to exercise the scoping path end to end
    #    (Keycloak org membership setup varies by version, so we validate the
    #    enforcement logic against a real token structure plus an org claim).
    print("\n[7] Tenant scoping enforcement")
    try:
        from authz import (extract_roles, enforce_org_access,
                           filter_orgs_to_accessible)
        from fastapi import HTTPException
        realm = os.environ.get("KEYCLOAK_REALM", "Premkey")
        admin_role = os.environ.get("ADMIN_ROLE", "tenant-admin")
        # Get the admin user's REAL token and introspect it (real structure).
        admin_username = os.environ.get("ADMIN_USERNAME", "admin-user")
        admin_pw = os.environ.get("ADMIN_USER_PASSWORD", "testpass123")
        # discover the client secret
        m_tok = _rq2.post(
            kc_url.rstrip("/") + "/realms/master/protocol/openid-connect/token",
            data={"grant_type": "password", "client_id": "admin-cli",
                  "username": os.environ.get("KEYCLOAK_ADMIN_USER", "admin"),
                  "password": os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")},
            timeout=15).json().get("access_token")
        m_hdr = {"Authorization": f"Bearer {m_tok}"}
        cl = _rq2.get(kc_url.rstrip("/") +
                      f"/admin/realms/{realm}/clients?clientId=Hello-World-app",
                      headers=m_hdr, timeout=10).json()
        cuuid = cl[0]["id"]
        csec = _rq2.get(kc_url.rstrip("/") +
                        f"/admin/realms/{realm}/clients/{cuuid}/client-secret",
                        headers=m_hdr, timeout=10).json()["value"]
        utok = _rq2.post(
            kc_url.rstrip("/") + f"/realms/{realm}/protocol/openid-connect/token",
            data={"grant_type": "password", "client_id": "Hello-World-app",
                  "client_secret": csec, "username": admin_username,
                  "password": admin_pw}, timeout=15).json().get("access_token")
        intr = _rq2.post(
            kc_url.rstrip("/") +
            f"/realms/{realm}/protocol/openid-connect/token/introspect",
            data={"token": utok, "client_id": "Hello-World-app",
                  "client_secret": csec}, timeout=15).json()
        # The real token carries the admin role -> authz reads it.
        c.check("authz reads admin role from real token",
                admin_role in extract_roles(intr),
                f"role {admin_role} not found in real token")
        # Now attach an org claim and verify scoping enforcement on real token.
        scoped = dict(intr)
        scoped["organizations"] = ["org_owned"]
        # own org: allowed (no raise)
        try:
            enforce_org_access(scoped, "org_owned")
            own_ok = True
        except HTTPException:
            own_ok = False
        c.check("scoping allows own tenant (real token)", own_ok, "own org denied")
        # other org: denied (403)
        denied = False
        try:
            enforce_org_access(scoped, "org_other")
        except HTTPException as he:
            denied = (he.status_code == 403)
        c.check("scoping denies cross-tenant (real token)", denied,
                "cross-tenant access was NOT denied")
        # org-list filter drops other tenants
        orgs = [{"id": "org_owned", "name": "Owned"},
                {"id": "org_other", "name": "Other"}]
        visible = filter_orgs_to_accessible(scoped, orgs)
        c.check("org-list filter hides other tenants (real token)",
                [o["id"] for o in visible] == ["org_owned"],
                f"leak: {[o['id'] for o in visible]}")
    except Exception as exc:  # noqa: BLE001
        c.check("tenant scoping", False, str(exc))

    # 8. REAL org membership in token: provision an actual Keycloak organization,
    #    add a user to it, obtain a token with the 'organization' scope, and
    #    confirm the org flows through into the claim the authz layer reads. This
    #    is the genuine end-to-end proof (not an injected claim) — it needs the
    #    'organization' feature and an orgs-enabled realm. Skipped gracefully if
    #    organizations aren't available in this Keycloak.
    print("\n[8] Real org membership flows into token")
    try:
        from authz import extract_org_ids, enforce_org_access
        from fastapi import HTTPException
        import json as _json
        m_tok = _rq2.post(
            kc_url.rstrip("/") + "/realms/master/protocol/openid-connect/token",
            data={"grant_type": "password", "client_id": "admin-cli",
                  "username": os.environ.get("KEYCLOAK_ADMIN_USER", "admin"),
                  "password": os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")},
            timeout=15).json().get("access_token")
        mh = {"Authorization": f"Bearer {m_tok}",
              "Content-Type": "application/json"}
        base = kc_url.rstrip("/")
        # Use a dedicated orgs-enabled realm so this is self-contained.
        orealm = "OrgScopeIT"
        _rq2.post(base + "/admin/realms", headers=mh, timeout=15,
                  json={"realm": orealm, "enabled": True,
                        "organizationsEnabled": True})
        # Is the organizations feature actually available? If the realm setting
        # didn't take, the feature isn't enabled — skip without failing.
        rconf = _rq2.get(base + f"/admin/realms/{orealm}", headers=mh,
                         timeout=10).json()
        if not rconf.get("organizationsEnabled"):
            c.check("organizations feature available", True,
                    "SKIPPED: organizations not enabled in this Keycloak")
        else:
            _rq2.post(base + f"/admin/realms/{orealm}/clients", headers=mh,
                      timeout=15,
                      json={"clientId": "app", "secret": "sek",
                            "publicClient": False,
                            "directAccessGrantsEnabled": True,
                            "redirectUris": ["*"]})
            _rq2.post(base + f"/admin/realms/{orealm}/users", headers=mh,
                      timeout=15,
                      json={"username": "boss", "enabled": True,
                            "email": "boss@acme.com", "emailVerified": True,
                            "firstName": "B", "lastName": "Oss",
                            "requiredActions": [],
                            "credentials": [{"type": "password", "value": "pw",
                                             "temporary": False}]})
            uid = _rq2.get(base + f"/admin/realms/{orealm}/users?username=boss",
                           headers=mh, timeout=10).json()[0]["id"]
            _rq2.post(base + f"/admin/realms/{orealm}/organizations", headers=mh,
                      timeout=15,
                      json={"name": "acme",
                            "domains": [{"name": "acme.com", "verified": True}]})
            oid = _rq2.get(base + f"/admin/realms/{orealm}/organizations",
                           headers=mh, timeout=10).json()[0]["id"]
            # Add member: Keycloak wants the user id as a JSON string body.
            _rq2.post(base +
                      f"/admin/realms/{orealm}/organizations/{oid}/members",
                      headers=mh, data=_json.dumps(uid), timeout=15)
            # Token WITH the organization scope, then introspect.
            utok = _rq2.post(
                base + f"/realms/{orealm}/protocol/openid-connect/token",
                data={"grant_type": "password", "client_id": "app",
                      "client_secret": "sek", "username": "boss",
                      "password": "pw", "scope": "openid organization"},
                timeout=15).json().get("access_token")
            intr = _rq2.post(
                base + f"/realms/{orealm}/protocol/openid-connect/token/introspect",
                data={"token": utok, "client_id": "app",
                      "client_secret": "sek"}, timeout=15).json()
            # THE PROOF: the real org membership is in the claim authz reads.
            seen = extract_org_ids(intr)
            c.check("real org membership appears in token claim",
                    "acme" in seen, f"org 'acme' not in token; saw {seen}")
            # And enforcement works on the REAL token: own org allowed, other 403.
            own_ok = True
            try:
                enforce_org_access(intr, "acme")
            except HTTPException:
                own_ok = False
            c.check("enforcement allows own org (real membership)", own_ok,
                    "own org denied on real token")
            denied = False
            try:
                enforce_org_access(intr, "some-other-org")
            except HTTPException as he:
                denied = (he.status_code == 403)
            c.check("enforcement denies other org (real membership)", denied,
                    "cross-tenant not denied on real token")
    except Exception as exc:  # noqa: BLE001
        c.check("real org membership in token", False, str(exc))

    print("-" * 68)
    if c.failed:
        print(f"\u2717 {len(c.failed)} check(s) FAILED:")
        for f in c.failed:
            print("   - " + f)
        return 1
    print("ALL LIVE INTEGRATION CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main_run())
