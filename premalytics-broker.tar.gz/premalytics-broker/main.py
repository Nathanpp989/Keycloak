#!/usr/bin/env python3
import json
import logging
import time
import os
import re
import stat
import tempfile
import uuid
from contextlib import asynccontextmanager

import requests
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from fastapi import FastAPI, Depends, HTTPException, Form, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import JSONResponse, Response
from fastapi.security import HTTPBearer
from authorize import router as auth0_router, oauth2_scheme
from keycloak import KeycloakOpenID, KeycloakAdmin
from keycloak.exceptions import KeycloakAuthenticationError

# User-flow integration (auth0_connect.py / auth0_talk.py / auth0_type.py)
from auth0_connect import Auth0Connect, get_keycloak_admin_token
from auth0_talk import KeycloakAdminAPI, Auth0UsersAPI, Auth0AuthzExtensionAPI, Auth0OrganizationsAPI
from auth0_type import UserManager

# Configure logging before anything else so all logger.* calls produce output.
# Structured JSON by default (LOG_FORMAT=text for human-readable local dev).
# This changes only the OUTPUT format — every logger.*() call site is unchanged.
from logging_config import configure_logging, request_id_var  # noqa: E402
from metrics import (  # noqa: E402
    metrics_middleware, render_metrics,
    record_token_result, record_forward_auth,
)
configure_logging()
logger = logging.getLogger(__name__)

# ── Configuration (single source of truth) ────────────────────────────────────
# Fix #3: realm and client id are read once here so setup, the OIDC client, and
# the user manager all operate on the SAME realm/client. Previously the realm was
# hardcoded "Premkey" in some places and read from KEYCLOAK_REALM in others.
KEYCLOAK_URL       = os.environ.get("KEYCLOAK_URL", "http://localhost:8080/")
KEYCLOAK_REALM     = os.environ.get("KEYCLOAK_REALM", "Premkey")
KEYCLOAK_CLIENT_ID = os.environ.get("KEYCLOAK_CLIENT_ID", "Hello-World-app")
# Where the browser is sent back after a brokered login. This MUST be registered
# on the Keycloak client or Keycloak rejects the auth request with
# "Invalid parameter: redirect_uri" — so the app provisions it at startup
# (see ensure_keycloak_client) rather than relying on manual admin-console setup.
APP_REDIRECT_URI   = os.environ.get("APP_REDIRECT_URI",
                                    "http://localhost:8000/callback")

# ── RSA key management ────────────────────────────────────────────────────────
public_pem: bytes = b""

def _write_atomic(path: str, data: bytes, mode: int = 0o644):
    """Write data to path atomically; set permissions before rename."""
    dir_ = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=dir_)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except Exception:
        # Clean up the temp file, then RE-RAISE. Silently swallowing a failed
        # key write would leave the app running with no/partial key material and
        # no signal that anything went wrong — far worse than failing loudly.
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
        raise

def init_rsa_keys():
    global public_pem
    # B108 fix: default to a USER-PRIVATE directory, not world-writable /tmp
    # (symlink/pre-creation risk on shared hosts). Containers override via
    # KEY_DIR=/data/keys. The directory is forced to 0700 either way.
    KEY_DIR = os.environ.get(
        "KEY_DIR", os.path.join(os.path.expanduser("~"), ".auth-broker", "keys"))
    os.makedirs(KEY_DIR, exist_ok=True)
    os.chmod(KEY_DIR, 0o700)
    private_key_path = os.path.join(KEY_DIR, "private.pem")
    public_key_path  = os.path.join(KEY_DIR, "public.pem")
    try:
        with open(public_key_path, "rb") as f:
            public_pem = f.read()
        with open(private_key_path, "rb"):
            pass
    except FileNotFoundError:
        _priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        private_bytes = _priv.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        )
        _pub_pem = _priv.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        _write_atomic(private_key_path, private_bytes, mode=stat.S_IRUSR | stat.S_IWUSR)
        _write_atomic(public_key_path, _pub_pem)
        public_pem = _pub_pem

# ── Keycloak helpers ──────────────────────────────────────────────────────────
def create_keycloak_user(admin: KeycloakAdmin, username: str, password: str, group: str):
    existing = admin.get_users({"username": username, "exact": "true"})
    if existing:
        return existing[0]["id"]
    groups = admin.get_groups()
    group_id = next((g["id"] for g in groups if g["name"] == group), None)
    if not group_id:
        group_id = admin.create_group({"name": group})
    user_id = admin.create_user({
        "username":    username,
        "enabled":     True,
        "email":         f"{username}@local.invalid",
        "emailVerified": True,
        "firstName":     username,
        "lastName":      username,
        "requiredActions": [],
        "credentials": [{"type": "password", "value": password, "temporary": False}],
    })
    # Some Keycloak versions/realm profiles don't persist all fields on create,
    # leaving the account "not fully set up" so the password grant fails with a
    # generic invalid_grant (surfaced as a 503 by /token). Explicitly finalize
    # the account with an update, then (re)set the password non-temporary. This
    # is idempotent and reliable across versions. Best-effort: a failure here
    # shouldn't crash startup, so it's guarded.
    try:
        admin.update_user(user_id, {
            "enabled": True,
            "emailVerified": True,
            "email": f"{username}@local.invalid",
            "firstName": username,
            "lastName": username,
            "requiredActions": [],
        })
        admin.set_user_password(user_id, password, temporary=False)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not finalize user '%s' (login may require manual "
                       "setup in Keycloak): %s", username, exc)
    admin.group_user_add(user_id, group_id)
    return user_id

def ensure_keycloak_client(admin: KeycloakAdmin) -> str:
    """
    Guarantee the app's Keycloak client exists AND is configured for the
    brokered browser login. Returns the client's internal UUID.

    ROOT-CAUSE FIX for "Invalid parameter: redirect_uri": setup_keycloak used to
    only *look up* the client (admin.get_client_id) and never provisioned its
    redirectUris, so the client either didn't exist or had no redirect URI
    registered — and Keycloak rejects any auth request whose redirect_uri isn't
    on the client's list. This function now:
      - creates the client if it's missing, with the redirect URI registered
      - otherwise adds the redirect URI (plus an origin wildcard) if absent
      - enables the standard (authorization-code) flow, required for browser login

    It is idempotent: safe to run on every startup.
    """
    from urllib.parse import urlparse

    parsed = urlparse(APP_REDIRECT_URI)
    wildcard = f"{parsed.scheme}://{parsed.netloc}/*"
    wanted_uris = [APP_REDIRECT_URI, wildcard]

    client_uuid = admin.get_client_id(KEYCLOAK_CLIENT_ID)
    if not client_uuid:
        logger.info("Keycloak client '%s' not found — creating it", KEYCLOAK_CLIENT_ID)
        admin.create_client({
            "clientId":             KEYCLOAK_CLIENT_ID,
            "enabled":              True,
            "protocol":             "openid-connect",
            "publicClient":         False,   # confidential: we use a client secret
            "standardFlowEnabled":  True,    # authorization-code (browser) flow
            "directAccessGrantsEnabled": True,  # password grant used by /token
            "redirectUris":         wanted_uris,
            "webOrigins":           [f"{parsed.scheme}://{parsed.netloc}"],
        }, skip_exists=True)
        client_uuid = admin.get_client_id(KEYCLOAK_CLIENT_ID)
        if not client_uuid:
            raise RuntimeError(
                f"Could not create or find Keycloak client '{KEYCLOAK_CLIENT_ID}' "
                f"in realm '{KEYCLOAK_REALM}'.")
        return client_uuid

    # Client exists — make sure the browser login can actually use it.
    rep = admin.get_client(client_uuid)
    # Defensive (same class as the P2 introspect fix): if the admin API returns
    # anything other than a client representation, don't crash the whole startup
    # on an AttributeError — log and leave the existing config alone.
    if not isinstance(rep, dict):
        logger.warning("Keycloak returned an unexpected representation for client "
                       "'%s' (%s); skipping redirect-URI provisioning.",
                       KEYCLOAK_CLIENT_ID, type(rep).__name__)
        return client_uuid
    uris = list(rep.get("redirectUris") or [])
    updates: dict = {}
    missing = [u for u in wanted_uris if u not in uris]
    if missing:
        uris.extend(missing)
        updates["redirectUris"] = uris
    if not rep.get("standardFlowEnabled"):
        updates["standardFlowEnabled"] = True
    # Heal directAccessGrantsEnabled too. The /token endpoint uses the password
    # (direct access) grant; if an existing client was created without this flag
    # (e.g. by hand, or by an older version of this code), every /token login
    # fails with 'unauthorized_client: Client not allowed for direct access
    # grants'. The create path sets this, so the update path must too — otherwise
    # a pre-existing client silently can't serve /token.
    if not rep.get("directAccessGrantsEnabled"):
        updates["directAccessGrantsEnabled"] = True
    if updates:
        admin.update_client(client_uuid, {**rep, **updates})
        logger.info("Updated Keycloak client '%s': %s",
                    KEYCLOAK_CLIENT_ID, ", ".join(sorted(updates)))
    return client_uuid


def _ensure_realm(admin_url: str, realm: str, user: str, pw: str,
                  timeout: int = 10) -> None:
    """
    Create the target realm if it doesn't exist yet.

    Without this, a FRESH Keycloak has only the 'master' realm, and every admin
    call against KEYCLOAK_REALM fails with 404 'Realm not found' — the app could
    never bootstrap a clean Keycloak, only one where the realm was created by
    hand. (Mocked tests hid this because KeycloakAdmin was a MagicMock.)

    Uses the admin REST API directly with a master-realm token, since we need to
    act before a realm-scoped KeycloakAdmin can work.
    """
    import requests as _rq
    base = admin_url.rstrip("/")
    # Get an admin token from the master realm.
    tr = _rq.post(
        f"{base}/realms/master/protocol/openid-connect/token",
        data={"grant_type": "password", "client_id": "admin-cli",
              "username": user, "password": pw}, timeout=timeout)
    tr.raise_for_status()
    token = tr.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    # Does the realm already exist?
    r = _rq.get(f"{base}/admin/realms/{realm}", headers=headers, timeout=timeout)
    if r.status_code == 200:
        return
    if r.status_code != 404:
        r.raise_for_status()
    # Create it (enabled, with login/registration usable for the app's flows).
    cr = _rq.post(f"{base}/admin/realms", headers=headers, timeout=timeout,
                  json={"realm": realm, "enabled": True})
    if cr.status_code not in (201, 409):   # 409 = created concurrently, fine
        cr.raise_for_status()
    logger.info("Created Keycloak realm '%s'", realm)


def setup_keycloak() -> str:
    """
    Ensure the realm's auth flow, default user, and client secret exist.
    Returns the client's actual secret so the app can authenticate as a
    confidential client (fixes the secret never being wired into keycloak_oidc).
    """
    admin_url = os.environ.get("KEYCLOAK_URL", "http://localhost:8080/")
    admin_user = os.environ.get("KEYCLOAK_ADMIN_USER", "admin")
    admin_pass = os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")
    # Create the realm first if it's missing — otherwise every call below 404s
    # on a fresh Keycloak.
    _ensure_realm(admin_url, KEYCLOAK_REALM, admin_user, admin_pass)
    admin = KeycloakAdmin(
        server_url=admin_url,
        username=admin_user,
        password=admin_pass,
        realm_name=KEYCLOAK_REALM,
        user_realm_name="master",
        verify=True
    )
    flows = admin.get_authentication_flows()
    if not any(flow["alias"] == "Hello-World-flow" for flow in flows):
        admin.create_authentication_flow({
            "alias":       "Hello-World-flow",
            "description": "Authentication flow for Hello World app",
            "providerId":  "basic-flow",
            "topLevel":    True,
            "builtIn":     False
        })
    default_password = os.environ.get("DEFAULT_USER_PASSWORD", "change-me")
    create_keycloak_user(admin, "user", default_password, "users")

    client_uuid     = ensure_keycloak_client(admin)
    existing_secret = admin.get_client_secrets(client_uuid)
    secret_value    = existing_secret.get("value")
    if secret_value is None:
        # M1 FIX: the python-keycloak method is generate_client_secrets —
        # create_client_secret does not exist (AttributeError on real library;
        # hidden in tests by MagicMock accepting any attribute).
        created = admin.generate_client_secrets(client_uuid)
        secret_value = created.get("value") if isinstance(created, dict) else None
    # Fix #2: return the real secret (env override wins if explicitly set)
    return os.environ.get("KEYCLOAK_CLIENT_SECRET") or secret_value or ""

# ── Lifespan ──────────────────────────────────────────────────────────────────
keycloak_oidc: KeycloakOpenID | None = None
user_manager: UserManager | None = None

def _build_user_manager() -> UserManager | None:
    """
    Wire up the UserManager from auth0_type using a fresh Keycloak admin token
    and an Auth0 M2M client. Returns None (with a warning) if the required
    Auth0 env vars are missing, or if the Auth0 management subsystem is turned
    off / auto-disabled (see features.py), so the rest of the app still starts.

    NOTE: this controls the Auth0 MANAGEMENT surface only. Keycloak still
    brokers browser logins through Auth0 regardless — that link is
    architectural and has no off switch.
    """
    # Explicit AUTH0_MANAGEMENT_MODE=off, or auto-disable when Auth0 is
    # unreachable, short-circuits before any network call.
    try:
        from features import auth0_management_state
        state = auth0_management_state()
        if not state.enabled:
            logger.warning(
                "Auth0 management disabled (%s) — user/organization endpoints "
                "will return 503. Brokered login through Auth0 is unaffected.",
                state.reason)
            return None
    except Exception as exc:  # noqa: BLE001 - never let flag logic break startup
        logger.warning("feature-flag check failed (%s); continuing with the "
                       "env-var check below", exc)

    keycloak_url = KEYCLOAK_URL
    realm        = KEYCLOAK_REALM
    admin_user   = os.environ.get("KEYCLOAK_ADMIN_USER", "admin")
    admin_pass   = os.environ.get("KEYCLOAK_ADMIN_PASSWORD", "admin")

    auth0_domain = os.environ.get("AUTH0_DOMAIN")
    auth0_id     = os.environ.get("AUTH0_CLIENT_ID")
    auth0_secret = os.environ.get("AUTH0_CLIENT_SECRET")
    if not (auth0_domain and auth0_id and auth0_secret):
        logger.warning(
            "Auth0 env vars missing — user-management endpoints will be disabled. "
            "Set AUTH0_DOMAIN, AUTH0_CLIENT_ID, AUTH0_CLIENT_SECRET to enable them."
        )
        return None

    # Provide a token-getter so KeycloakAdminAPI always uses a FRESH admin token.
    # Keycloak admin tokens expire in ~60s, so a one-time token would break the
    # endpoints a minute after startup.
    def kc_token_getter() -> str:
        return get_keycloak_admin_token(keycloak_url, admin_user, admin_pass)

    keycloak_api   = KeycloakAdminAPI(keycloak_url, kc_token_getter, realm)
    auth0_conn     = Auth0Connect(auth0_domain, auth0_id, auth0_secret)
    auth0_users    = Auth0UsersAPI(auth0_conn)
    # Optional Auth0 Authorization Extension (groups) — only if its URL is set.
    authz = None
    authz_url = os.environ.get("AUTH0_AUTHZ_EXTENSION_URL")
    if authz_url:
        authz = Auth0AuthzExtensionAPI(auth0_conn, authz_url)
    # Auth0 Organizations are always available via the Management API.
    auth0_orgs = Auth0OrganizationsAPI(auth0_conn)
    return UserManager(keycloak_api, auth0_users, auth0_authz=authz, auth0_orgs=auth0_orgs)


def _setup_keycloak_with_retry() -> str:
    """
    Call setup_keycloak() with retry + exponential backoff, so the app can start
    in a container before Keycloak is fully ready (a common race even with
    compose 'depends_on'). Tunable via env vars:
      KEYCLOAK_STARTUP_RETRIES (default 10)
      KEYCLOAK_STARTUP_BACKOFF (default 2.0 seconds, doubles each attempt, capped)
    Raises the last error if all attempts fail.
    """

    retries = int(os.environ.get("KEYCLOAK_STARTUP_RETRIES", "10"))
    backoff = float(os.environ.get("KEYCLOAK_STARTUP_BACKOFF", "2.0"))
    max_backoff = 30.0
    last_exc: Exception | None = None

    for attempt in range(1, retries + 1):
        try:
            return setup_keycloak()
        except Exception as exc:  # noqa: BLE001 — we deliberately retry on any error
            last_exc = exc
            if attempt == retries:
                break
            wait = min(backoff * (2 ** (attempt - 1)), max_backoff)
            logger.warning(
                "Keycloak not ready (attempt %d/%d): %s — retrying in %.1fs",
                attempt, retries, exc, wait,
            )
            time.sleep(wait)

    raise RuntimeError(
        f"Keycloak setup failed after {retries} attempts"
    ) from last_exc


@asynccontextmanager
async def lifespan(app: FastAPI):
    global keycloak_oidc, user_manager
    try:
        init_rsa_keys()
    except Exception as exc:
        logger.error("RSA key initialisation failed: %s", exc)
        raise
    try:
        client_secret = _setup_keycloak_with_retry()
    except Exception as exc:
        logger.error("Keycloak setup failed after retries — check KEYCLOAK_URL "
                     "and credentials: %s", exc)
        # By default this is fatal: Keycloak is the core of this service, and
        # starting without it would serve endpoints that cannot possibly work.
        # KEYCLOAK_REQUIRED=false opts into a DEGRADED start instead, so the
        # process comes up and /status/subsystems can be used to diagnose why
        # — useful in dev and during an outage. Auth endpoints then return 503
        # with a clear reason rather than the app being unreachable entirely.
        if os.environ.get("KEYCLOAK_REQUIRED", "true").strip().lower() \
                in ("false", "0", "no", "off"):
            logger.warning(
                "KEYCLOAK_REQUIRED=false — starting in DEGRADED mode. "
                "Auth endpoints will fail until Keycloak is reachable.")
            keycloak_oidc = None
            user_manager = None
            yield
            return
        raise
    if not client_secret:
        logger.warning(
            "No Keycloak client secret available for '%s'. Confidential-client "
            "operations (/token, introspection) will fail. Set KEYCLOAK_CLIENT_SECRET "
            "or ensure the client has a secret in Keycloak.", KEYCLOAK_CLIENT_ID
        )
    keycloak_oidc = KeycloakOpenID(
        server_url=KEYCLOAK_URL,
        client_id=KEYCLOAK_CLIENT_ID,
        realm_name=KEYCLOAK_REALM,
        client_secret_key=client_secret,   # Fix #2: real secret, not a placeholder
    )
    # Build the user manager; don't let its failure crash the whole app
    try:
        user_manager = _build_user_manager()
    except Exception as exc:
        logger.error("Could not initialise user manager: %s", exc)
        user_manager = None
    yield

app = FastAPI(lifespan=lifespan)
app.include_router(auth0_router)


@app.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    """Assign every request a correlation ID and thread it through logging.

    - If the caller (Traefik, a client, or an upstream service) already sent an
      X-Request-ID, we REUSE it so the same ID spans the whole call chain
      (Traefik -> app -> any downstream). Otherwise we generate one.
    - The ID is stored in a contextvar, so every log line emitted while handling
      this request automatically includes it (see logging_config.JSONFormatter).
    - We echo it back in the X-Request-ID response header so callers and the
      proxy can correlate their view with ours.
    """
    incoming = request.headers.get("X-Request-ID", "").strip()
    # Reuse a sane inbound id; otherwise mint one. Cap length to avoid a
    # malicious client stuffing a huge header into every log line.
    rid = incoming[:128] if incoming else uuid.uuid4().hex
    token = request_id_var.set(rid)
    try:
        response = await call_next(request)
    finally:
        request_id_var.reset(token)
    response.headers["X-Request-ID"] = rid
    return response


# Record request count + latency for every request. Registered after the
# correlation-id middleware so timing wraps the whole handler.
app.middleware("http")(metrics_middleware)


http_bearer     = HTTPBearer()

# ── Auth dependency ───────────────────────────────────────────────────────────
def _introspect_token(token: str) -> dict:
    """
    Validate a bearer token via Keycloak introspection and return the token-info
    dict. Raises HTTPException(401/503) on failure. Shared by the HTTP dependency
    and the WebSocket handler so both enforce identical rules.
    """
    if keycloak_oidc is None:
        raise HTTPException(status_code=503, detail="Authentication service unavailable")
    try:
        token_info = keycloak_oidc.introspect(token)
    except Exception as exc:
        logger.error("Token introspection failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Authentication service unavailable")
    # P2 FIX: introspect can return None / a non-dict on some error responses;
    # guard before calling .get() so this surfaces as 401, not an unhandled 500.
    if not isinstance(token_info, dict) or not token_info.get("active"):
        raise HTTPException(status_code=401, detail="Token is inactive or expired")
    return token_info


def require_keycloak_auth(credentials=Depends(http_bearer)) -> dict:
    """
    FastAPI dependency: validate the bearer token via Keycloak introspection.
    Returns the token info dict on success; raises 401/503 otherwise.
    Used to protect endpoints that must only be reachable by authenticated users.
    """
    return _introspect_token(credentials.credentials)

# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/")
def read_root():
    return {"message": "Hello, World!"}

@app.get("/status/subsystems")
def subsystem_status():
    """
    Which optional subsystems are live right now, and why. Useful when an
    endpoint returns 503: this says whether the backend is off by config, or
    auto-disabled because it's unreachable.

    Note: 'auth0_management' covers the Auth0 Management API only. Keycloak
    brokers browser logins through Auth0 regardless of this flag.
    """
    try:
        from features import auth0_management_state, openbao_state
        out = {}
        for st in (auth0_management_state(), openbao_state()):
            out[st.name] = {"enabled": st.enabled, "mode": st.mode,
                            "reason": st.reason}
        out["note"] = ("auth0 brokered-login IdP is architectural and has no "
                       "off switch; these flags cover optional surfaces only")
        return out
    except Exception as exc:  # noqa: BLE001
        return {"error": f"could not resolve subsystem status: {exc}"}

@app.get("/metrics")
def metrics_endpoint():
    """Prometheus metrics endpoint. Scrape this for request rates, latencies,
    and auth outcomes. Public (no auth) so a scraper can reach it — it exposes
    only aggregate counters, no secrets or per-user data. If you need to lock it
    down, restrict it at the Traefik layer to your monitoring network."""
    body, content_type = render_metrics()
    return Response(content=body, media_type=content_type)


@app.get("/health/live")
def health_live():
    """Liveness: is the process up and serving? This must NOT check external
    dependencies — a liveness probe failing tells an orchestrator to RESTART the
    container, and restarting won't fix a downstream outage (it'd just crash-loop
    while Keycloak is down). So liveness only proves the event loop is running.
    """
    return {"status": "alive"}


@app.get("/health/ready")
def health_ready():
    """Readiness: can the app actually serve auth right now? Unlike liveness,
    this DOES check the critical dependency: keycloak_oidc is None when the app
    started degraded (Keycloak unreachable), so it can't issue or validate
    tokens. A failing readiness probe tells a load balancer to stop sending
    traffic here WITHOUT restarting — the right response to a transient
    dependency outage. Returns 503 when not ready so orchestrators/monitors read
    it correctly."""
    if keycloak_oidc is None:
        return JSONResponse(
            status_code=503,
            content={"status": "not_ready",
                     "reason": "Keycloak not connected (degraded start or outage)"},
        )
    return {"status": "ready"}


@app.get("/hello")
def read_hello(email: str, username: str):
    return {"email": email, "username": username}

@app.post("/token")
def login(request: Request,
          username: str = Form(...), password: str = Form(...)):
    # Rate-limit BEFORE touching Keycloak: a brute-force attempt shouldn't even
    # reach the auth server. Fail-open — a limiter bug must not block all logins.
    try:
        from rate_limit import login_limiter, client_key
        allowed, retry = login_limiter().check_and_consume(client_key(request))
        if not allowed:
            raise HTTPException(
                status_code=429, detail="Too many login attempts; slow down.",
                headers={"Retry-After": str(int(retry) + 1)})
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.warning("rate limiter error on /token (allowing): %s", exc)
    if keycloak_oidc is None:
        raise HTTPException(status_code=503, detail="Authentication service unavailable")
    try:
        token_response = keycloak_oidc.token(username, password)
        record_token_result("success")
        return {"access_token": token_response["access_token"], "token_type": "bearer"}
    except KeycloakAuthenticationError:
        record_token_result("invalid_credentials")
        raise HTTPException(status_code=401, detail="Invalid credentials")
    except Exception as exc:
        # Log the REAL cause. Returning a bare 503 with no server-side log is
        # what made the "Account is not fully set up" startup bug invisible for
        # so long — an operator saw 503 and had nothing to go on. The client
        # still gets a generic message; the diagnostic detail goes to the log.
        record_token_result("error")
        logger.error("Token request failed for user '%s': %s",
                     username, exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Authentication service unavailable")

@app.get("/protected")
def protected_route(token_info: dict = Depends(require_keycloak_auth)):
    return {"message": f"Hello, {token_info.get('preferred_username', 'user')}!"}


@app.api_route("/auth/forward", methods=["GET", "POST", "PUT", "DELETE",
                                          "PATCH", "HEAD", "OPTIONS"])
def traefik_forward_auth(request: Request):
    """
    Traefik ForwardAuth endpoint.

    Traefik's ForwardAuth middleware calls this on every request to a protected
    service, forwarding the ORIGINAL request's headers. A 2xx response means
    "allow" and Traefik proceeds to the upstream; any non-2xx means "deny" and
    Traefik returns that status to the client instead of proxying.

    Contract details that matter:
    - Traefik forwards the original Authorization header, so we validate the
      same bearer token the app's own endpoints use (via _introspect_token) —
      one source of truth for "is this token valid", reused here.
    - On allow, we return identity headers (X-Auth-User, X-Auth-Subject). Traefik
      copies back only the headers named in its `authResponseHeaders` config, so
      the upstream service can trust these WITHOUT re-validating — but only
      because they arrive from Traefik, which stripped any client-supplied copies
      first (see the compose/dynamic config). We do not trust inbound X-Auth-*.
    - The original method/path/host arrive as X-Forwarded-* headers; we log them
      for auditability but authorization here is authentication-only (valid token
      => allow). Per-route authorization is enforced by Traefik's routing rules.

    Any missing/invalid token yields 401 (deny) rather than 503, because to
    Traefik a non-2xx is simply "deny" and 401 is the correct signal to the
    client; introspection-backend failures still surface as 503.
    """
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        # No credentials -> deny. 401 tells the client to authenticate.
        record_forward_auth("deny")
        raise HTTPException(status_code=401, detail="Missing bearer token",
                            headers={"WWW-Authenticate": "Bearer"})
    token = auth.split(" ", 1)[1].strip()
    if not token:
        record_forward_auth("deny")
        raise HTTPException(status_code=401, detail="Empty bearer token",
                            headers={"WWW-Authenticate": "Bearer"})

    # Reuse the app's single token-validation path. This raises 401 for an
    # inactive/expired token and 503 if the introspection backend is unreachable
    # — both correct signals for Traefik (401 deny, 503 = auth temporarily down).
    try:
        token_info = _introspect_token(token)
    except HTTPException:
        # 401 (invalid token) or 503 (backend down) both mean "not allowed".
        record_forward_auth("deny")
        raise

    # Allowed. Hand identity back to the upstream via response headers that
    # Traefik is configured to copy (authResponseHeaders). The upstream must
    # treat these as trusted ONLY when they arrive via Traefik.
    username = str(token_info.get("preferred_username", ""))
    subject = str(token_info.get("sub", ""))
    fwd_for = request.headers.get("x-forwarded-for", "")
    fwd_method = request.headers.get("x-forwarded-method", "")
    fwd_uri = request.headers.get("x-forwarded-uri", "")
    if fwd_method or fwd_uri:
        logger.info("ForwardAuth allow: user=%s %s %s (xff=%s)",
                    username or "?", fwd_method, fwd_uri, fwd_for)
    record_forward_auth("allow")
    return JSONResponse(
        status_code=200,
        content={"status": "authenticated"},
        headers={"X-Auth-User": username, "X-Auth-Subject": subject},
    )

@app.post("/oidc-token")
def oidc_login(token: str = Depends(oauth2_scheme)):
    if keycloak_oidc is None:
        raise HTTPException(status_code=503, detail="Authentication service unavailable")
    try:
        token_info = keycloak_oidc.introspect(token)
        if not isinstance(token_info, dict) or not token_info.get("active"):
            raise HTTPException(status_code=401, detail="Token is inactive or expired")
        return {"message": f"Hello, {token_info.get('preferred_username', 'user')}!"}
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Token introspection failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Authentication service unavailable")

@app.post("/register")
def register(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    username: str | None = Form(default=None),
):
    # Rate-limit account creation to curb automated signup spam. Fail-open.
    try:
        from rate_limit import register_limiter, client_key
        allowed, retry = register_limiter().check_and_consume(client_key(request))
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail="Too many registration attempts; slow down.",
                headers={"Retry-After": str(int(retry) + 1)})
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.warning("rate limiter error on /register (allowing): %s", exc)
    """
    Register a new user in BOTH Keycloak and Auth0 via the UserManager.
    If 'username' is omitted, one is derived from the email address.
    """
    if user_manager is None:
        raise HTTPException(
            status_code=503,
            detail="User management is unavailable (Auth0 not configured).",
        )
    try:
        result = user_manager.add_user(email=email, password=password, username=username)
    except RuntimeError as exc:
        # Surfaced for things like missing Auth0 scopes
        logger.error("Registration failed: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Unexpected registration error: %s", exc)
        raise HTTPException(status_code=500, detail="Registration failed")

    return {
        "message": f"User '{result['username']}' registered.",
        "username": result["username"],
        "email": result["email"],
        "keycloak_id": result["keycloak_id"],
        "auth0_id": result["auth0_id"],
        "pre_existing": result["pre_existing"],
    }

@app.get("/users/lookup")
def users_lookup(
    username: str,
    email: str,
    token_info: dict = Depends(require_keycloak_auth),
):
    """
    Report which system(s) a user belongs to (keycloak/auth0/both/neither).
    Protected: requires a valid Keycloak bearer token, because this endpoint
    reveals whether an account exists (a user-enumeration vector if left open).
    """
    if user_manager is None:
        raise HTTPException(
            status_code=503,
            detail="User management is unavailable (Auth0 not configured).",
        )
    try:
        system = user_manager.determine_user_system(username, email)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("User lookup failed: %s", exc)
        raise HTTPException(status_code=500, detail="Lookup failed")
    return {"username": username, "email": email, "system": system.value}

@app.get("/users/membership")
def users_membership(
    username: str,
    email: str,
    token_info: dict = Depends(require_keycloak_auth),
):
    """
    Return a user's groups and roles from BOTH Keycloak and Auth0, correlated.
    Protected: requires a valid Keycloak bearer token (same enumeration concern
    as /users/lookup).
    """
    if user_manager is None:
        raise HTTPException(
            status_code=503,
            detail="User management is unavailable (Auth0 not configured).",
        )
    try:
        return user_manager.get_membership(username, email)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Membership lookup failed: %s", exc)
        raise HTTPException(status_code=500, detail="Membership lookup failed")

@app.post("/groups")
def create_group(
    name: str = Form(...),
    parent_path: str | None = Form(default=None),
    token_info: dict = Depends(require_keycloak_auth),
):
    """
    Create a group (or subgroup if parent_path is given) in Keycloak and, if the
    Authorization Extension is configured, in Auth0. Protected.
    """
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.create_group(name, parent_path=parent_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Group creation failed: %s", exc)
        raise HTTPException(status_code=500, detail="Group creation failed")

@app.post("/users/groups")
def modify_group_membership(
    username: str = Form(...),
    email: str = Form(...),
    group_name: str = Form(...),
    action: str = Form(...),  # "add" or "revoke"
    token_info: dict = Depends(require_keycloak_auth),
):
    """
    Add or revoke a user's membership in a group across systems. Protected.
    `action` must be 'add' or 'revoke'.
    """
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    if action not in ("add", "revoke"):
        raise HTTPException(status_code=422, detail="action must be 'add' or 'revoke'")
    try:
        return user_manager.set_group_membership(
            username, email, group_name, add=(action == "add")
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Group membership change failed: %s", exc)
        raise HTTPException(status_code=500, detail="Group membership change failed")

@app.post("/users/roles")
def modify_user_role(
    username: str = Form(...),
    email: str = Form(...),
    role_name: str = Form(...),
    action: str = Form(...),  # "assign" or "revoke"
    token_info: dict = Depends(require_keycloak_auth),
):
    """
    Assign or revoke a role for a user across systems (Keycloak realm role +
    Auth0 Authorization Core role). Protected. `action` must be 'assign'/'revoke'.
    """
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    if action not in ("assign", "revoke"):
        raise HTTPException(status_code=422, detail="action must be 'assign' or 'revoke'")
    try:
        return user_manager.set_role(
            username, email, role_name, assign=(action == "assign")
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Role change failed: %s", exc)
        raise HTTPException(status_code=500, detail="Role change failed")

@app.patch("/groups")
def update_group_endpoint(
    group: str = Form(...),
    new_name: str = Form(...),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Rename a group (by path or name) across systems. Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.update_group(group, new_name)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Group update failed: %s", exc)
        raise HTTPException(status_code=500, detail="Group update failed")

@app.delete("/groups")
def delete_group_endpoint(
    group: str,
    token_info: dict = Depends(require_keycloak_auth),
):
    """Delete a group (by path or name) across systems. Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.delete_group(group)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Group delete failed: %s", exc)
        raise HTTPException(status_code=500, detail="Group delete failed")

@app.post("/organizations")
def create_organization_endpoint(
    name: str = Form(...),
    display_name: str | None = Form(default=None),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Create (or reuse) an Auth0 organization. Protected."""
    if user_manager is None or user_manager.auth0_orgs is None:
        raise HTTPException(status_code=503, detail="Organizations API unavailable.")
    try:
        return user_manager.auth0_orgs.create_organization(name, display_name=display_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Organization create failed: %s", exc)
        raise HTTPException(status_code=500, detail="Organization create failed")

@app.get("/organizations")
def list_organizations_endpoint(
    token_info: dict = Depends(require_keycloak_auth),
):
    """List Auth0 organizations. Protected."""
    if user_manager is None or user_manager.auth0_orgs is None:
        raise HTTPException(status_code=503, detail="Organizations API unavailable.")
    try:
        return {"organizations": user_manager.auth0_orgs.list_organizations()}
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Organization list failed: %s", exc)
        raise HTTPException(status_code=500, detail="Organization list failed")

@app.patch("/organizations/{org_id}")
def update_organization_endpoint(
    org_id: str,
    display_name: str = Form(...),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Update an Auth0 organization's display name. Protected."""
    if user_manager is None or user_manager.auth0_orgs is None:
        raise HTTPException(status_code=503, detail="Organizations API unavailable.")
    try:
        return user_manager.auth0_orgs.update_organization(org_id, display_name=display_name)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Organization update failed: %s", exc)
        raise HTTPException(status_code=500, detail="Organization update failed")

@app.delete("/organizations/{org_id}")
def delete_organization_endpoint(
    org_id: str,
    token_info: dict = Depends(require_keycloak_auth),
):
    """Delete an Auth0 organization. Protected."""
    if user_manager is None or user_manager.auth0_orgs is None:
        raise HTTPException(status_code=503, detail="Organizations API unavailable.")
    try:
        user_manager.auth0_orgs.delete_organization(org_id)
        return {"deleted": org_id}
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Organization delete failed: %s", exc)
        raise HTTPException(status_code=500, detail="Organization delete failed")

@app.post("/organizations/members")
def organization_membership_endpoint(
    email: str = Form(...),
    org_name: str = Form(...),
    action: str = Form(...),  # "add" or "remove"
    token_info: dict = Depends(require_keycloak_auth),
):
    """Add or remove a user (by email) from an Auth0 organization. Protected."""
    if user_manager is None or user_manager.auth0_orgs is None:
        raise HTTPException(status_code=503, detail="Organizations API unavailable.")
    if action not in ("add", "remove"):
        raise HTTPException(status_code=422, detail="action must be 'add' or 'remove'")
    try:
        status = user_manager.set_organization_membership(
            email, org_name, add=(action == "add")
        )
        return {"status": status}
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Organization membership change failed: %s", exc)
        raise HTTPException(status_code=500, detail="Organization membership change failed")

@app.patch("/users/metadata")
def set_user_metadata(
    username: str = Form(...),
    email: str = Form(...),
    metadata: str = Form(...),  # JSON object as a string
    token_info: dict = Depends(require_keycloak_auth),
):
    """Merge key/values into Keycloak attributes + Auth0 app_metadata. Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        parsed = json.loads(metadata)
        if not isinstance(parsed, dict):
            raise ValueError("metadata must be a JSON object")
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="metadata must be a JSON object string")
    try:
        return user_manager.set_user_metadata(username, email, parsed)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Metadata update failed: %s", exc)
        raise HTTPException(status_code=500, detail="Metadata update failed")

@app.post("/users/active")
def set_user_active(
    username: str = Form(...),
    email: str = Form(...),
    active: bool = Form(...),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Enable/disable (Keycloak) and unblock/block (Auth0) an account. Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.set_user_active(username, email, active)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Active-state change failed: %s", exc)
        raise HTTPException(status_code=500, detail="Active-state change failed")

@app.post("/users/verify-email")
def verify_email(
    username: str = Form(...),
    email: str = Form(...),
    action: str = Form(...),  # "set" (mark verified) or "send" (send the email)
    token_info: dict = Depends(require_keycloak_auth),
):
    """Mark email verified in both systems, or trigger verification emails. Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    if action not in ("set", "send"):
        raise HTTPException(status_code=422, detail="action must be 'set' or 'send'")
    try:
        if action == "set":
            return user_manager.set_email_verified(username, email, True)
        return user_manager.send_verification_email(username, email)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Email verification failed: %s", exc)
        raise HTTPException(status_code=500, detail="Email verification failed")

@app.post("/users/password-reset")
def password_reset(
    username: str = Form(...),
    email: str = Form(...),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Trigger a password reset in both systems (Auth0 returns a ticket URL). Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.trigger_password_reset(username, email)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Password reset failed: %s", exc)
        raise HTTPException(status_code=500, detail="Password reset failed")

@app.post("/users/logout")
def logout_user(
    username: str = Form(...),
    email: str = Form(...),
    token_info: dict = Depends(require_keycloak_auth),
):
    """Kill the user's sessions in both systems (Auth0 also revokes grants). Protected."""
    if user_manager is None:
        raise HTTPException(status_code=503,
                            detail="User management is unavailable (Auth0 not configured).")
    try:
        return user_manager.logout_everywhere(username, email)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("Logout failed: %s", exc)
        raise HTTPException(status_code=500, detail="Logout failed")

@app.get("/keys")
def get_keys():
    if not public_pem:
        raise HTTPException(status_code=503, detail="Keys not yet initialised")
    return {"public_key": public_pem.decode("utf-8")}


# ── GitHub relay over WebSocket ────────────────────────────────────────────────
GITHUB_API = "https://api.github.com"


def _resolve_github_token() -> str | None:
    """
    Resolve the optional GitHub token, preferring a managed secret store.

    Order: OpenBao/Key Vault via authorize.get_secret('GITHUB_TOKEN') (which
    itself honours OPENBAO_SECRETS and the feature flags), then the GITHUB_TOKEN
    env var for local dev. Any store error is swallowed — the token is optional,
    so a missing/broken store just means unauthenticated GitHub calls, never a
    request failure.
    """
    try:
        from authorize import get_secret
        val = get_secret("GITHUB_TOKEN")
        if val:
            return val
    except Exception:  # noqa: BLE001 - optional; fall through to env
        pass
    return os.environ.get("GITHUB_TOKEN")
# Only these resource shapes are allowed, so a client can't drive the server to
# fetch arbitrary URLs (SSRF guard). Each maps to a GitHub REST path builder.
_GITHUB_ROUTES = {
    "repo":      lambda p: f"/repos/{p['owner']}/{p['repo']}",
    "issues":    lambda p: f"/repos/{p['owner']}/{p['repo']}/issues",
    "user":      lambda p: f"/users/{p['username']}",
}


def fetch_github(resource: str, params: dict) -> dict:
    """
    Fetch an allow-listed GitHub resource. Returns a dict with 'status' and
    'data'. Never raises for HTTP errors — the status is returned to the client.
    Kept synchronous and small so it's easy to unit-test with `responses`.
    """
    builder = _GITHUB_ROUTES.get(resource)
    if builder is None:
        return {"status": 400, "error": f"unknown resource '{resource}'"}
    # W2 FIX: param values are interpolated into the URL path, so restrict them
    # to GitHub's identifier charset. Otherwise 'repo': 'x/collaborators' (or
    # '?', '#', '%2F') escapes the resource allow-list and reaches arbitrary
    # GitHub endpoints through the authenticated relay.
    for key, value in params.items():
        if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,100}", value):
            return {"status": 400,
                    "error": f"invalid value for parameter '{key}'"}
    try:
        path = builder(params)
    except (KeyError, TypeError):
        return {"status": 400, "error": f"missing parameters for resource '{resource}'"}
    headers = {"Accept": "application/vnd.github+json",
               "User-Agent": "keycloak-auth0-broker"}
    # Optional token lifts rate limits / allows private repos; never required.
    # Prefer a managed secret store (OpenBao/Key Vault) over a bare env var so
    # the token isn't sitting in the process environment in production; fall
    # back to the env var for local dev.
    gh_token = _resolve_github_token()
    if gh_token:
        headers["Authorization"] = f"Bearer {gh_token}"
    try:
        resp = requests.get(f"{GITHUB_API}{path}", headers=headers, timeout=10)
    except requests.RequestException as exc:
        return {"status": 502, "error": f"GitHub request failed: {exc}"}
    try:
        data = resp.json()
    except ValueError:
        data = None
    return {"status": resp.status_code, "data": data}


@app.websocket("/ws/github")
async def github_ws(websocket: WebSocket):
    """
    Authenticated WebSocket GitHub relay.

    Handshake: the client's FIRST message must be JSON {"token": "<keycloak
    access token>"}. The token is validated via Keycloak introspection (same
    rules as the HTTP endpoints). On success the server replies
    {"type": "auth_ok"}; on failure it sends {"type": "auth_error"} and closes.

    Thereafter each client message is {"resource": "...", "params": {...}} and
    the server responds with {"type": "result", ...} carrying GitHub's status
    and data. Unknown resources return a 400-style result rather than closing.
    """
    await websocket.accept()
    # 1. Authenticate on the first frame.
    try:
        raw = await websocket.receive_text()
        hello = json.loads(raw)
        token = hello.get("token", "")
    except (WebSocketDisconnect, json.JSONDecodeError, AttributeError):
        await websocket.close(code=1008)
        return
    try:
        _introspect_token(token)
    except HTTPException:
        # Don't leak whether it was 401 vs 503 over the socket; just refuse.
        try:
            await websocket.send_json({"type": "auth_error",
                                       "detail": "authentication failed"})
        finally:
            await websocket.close(code=1008)
        return
    await websocket.send_json({"type": "auth_ok"})

    # 2. Serve requests until the client disconnects.
    try:
        while True:
            # W3 FIX: a binary frame makes receive_text() raise KeyError —
            # report it instead of crashing the connection.
            try:
                msg = await websocket.receive_text()
            except KeyError:
                await websocket.send_json({"type": "error",
                                           "detail": "expected a text frame"})
                continue
            try:
                req = json.loads(msg)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "detail": "invalid JSON"})
                continue
            # W1 FIX: valid JSON that isn't an object ('42', '[1,2]', '"x"')
            # used to crash the handler via req.get().
            if not isinstance(req, dict):
                await websocket.send_json({"type": "error",
                                           "detail": "message must be a JSON object"})
                continue
            resource = req.get("resource")
            params = req.get("params") or {}
            if not isinstance(params, dict):
                await websocket.send_json({"type": "error",
                                           "detail": "'params' must be an object"})
                continue
            result = fetch_github(resource, params)
            await websocket.send_json({"type": "result", **result})
    except WebSocketDisconnect:
        return


if __name__ == "__main__":
    import uvicorn  # I4 FIX: lazy import — only needed when run directly
    uvicorn.run(
        app,
        # B104 fix: bind loopback by default for local runs; the container
        # opts into all interfaces explicitly via ENV HOST=0.0.0.0.
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "8000"))
    )
